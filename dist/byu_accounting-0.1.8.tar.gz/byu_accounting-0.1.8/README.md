# byu_accounting

This package contains functions used by BYU Accounting students in their data analytics courses.